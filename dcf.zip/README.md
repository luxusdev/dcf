DCFCoinCoin ($BPX)

algorithm: X13/PoS 1%

retarget: 10 minutes

total coins: 50 million

1 minute blocks with 4 confirms


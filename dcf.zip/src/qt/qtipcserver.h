#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define DCFCoin-Qt message queue name
#define BITCOINURI_QUEUE_NAME "DCFCoinURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H

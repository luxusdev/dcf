DCFCoin v1.0.1.0

Updates to GUI  and IPv6.





Offical DCFCoin found under DCFCoinDev/DCFCoin
